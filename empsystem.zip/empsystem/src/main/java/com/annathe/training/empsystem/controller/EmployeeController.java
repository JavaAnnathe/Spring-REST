package com.annathe.training.empsystem.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.annathe.training.empsystem.exception.EmployeeNotFoundException;
import com.annathe.training.empsystem.model.Employee;

@RestController
public class EmployeeController {
	
	
	Map<Integer,Employee> employeeDatabase = new HashMap<Integer,Employee>();
	
	
	
	
	@GetMapping("/employees/dummy") 
	public Employee getDummyEmployee() {
		
		Employee employee = new Employee();
		
		employee.setId(1000);
		employee.setName("Murugan");
		employee.setMessage("Dummy employee created");
		
		employeeDatabase.put(1000, employee);
		
		return employee;	
		
		
		
	}
	
	
	@GetMapping("/employees/{id}") 
	public Employee getEmployee(@PathVariable int id) {
		
		Employee  employee = new Employee();
		
		if(employeeDatabase.containsKey(id)) {
			employee = employeeDatabase.get(id);
			employee.setMessage("Employee retrieved");
			
		}
		else {
			//employee.setMessage("Employee not found");
			throw new EmployeeNotFoundException(id);
			
		}
				
		return employee;
	}
	
	@ExceptionHandler(EmployeeNotFoundException.class)
	public ResponseEntity<String> handleException(EmployeeNotFoundException e){
		
		return new ResponseEntity<String>("Employee not found for id:"+e.getId(),HttpStatus.NOT_FOUND);
		
		
		
	}
	
	@GetMapping("/employees") 
	public List<Employee> getAllEmployees() {
		
		List<Employee> employees  = new ArrayList<Employee>();
		
		Set<Integer> employeeIdKeys = employeeDatabase.keySet();
		
		for(Integer i: employeeIdKeys) {
			
			employees.add(employeeDatabase.get(i));
		}
			
		
		return employees;	
		
		
		
	}
	
	@PostMapping("/employees")
	public Employee createEmployee(@RequestBody Employee employee) {
		
		System.out.println("employee id: "+ employee.getId());
		if(employeeDatabase.containsKey(employee.getId())) {
			
			employee.setMessage("Employee already exist");
			
		}
		else {
			
			employeeDatabase.put(employee.getId(), employee);
			employee.setMessage("Employee created");
			
		}
				
		return employee;
		
		
	}
	
	@DeleteMapping("/employees/{id}")
	public Employee deleteEmployee(@PathVariable int id) {
		
		Employee  employee = new Employee();
		
		if(employeeDatabase.containsKey(id)) {
			employee = employeeDatabase.get(id);
			
			employeeDatabase.remove(id);
			
			employee.setMessage("Employee deleted");
			
		}
		else {
			
			employee.setMessage("Employee not found");
			
		}
				
		return employee;
		
		
		
	}
	
	
	@PutMapping("/employees/{id}") 
	public Employee updateEmployee(@PathVariable int id,@RequestBody Employee Modifiedemployee ) {
		
		Employee  employee = new Employee();
		
		if(employeeDatabase.containsKey(id)) {
			
			employee = employeeDatabase.get(id);
			employee.setName(Modifiedemployee.getName());
			
			employee.setMessage("Employee updated");
			
		}
		else {
			employee.setMessage("Employee not found");
			
		}
				
		return employee;
	}
	
	
}

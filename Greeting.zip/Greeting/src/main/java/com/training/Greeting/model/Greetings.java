package com.training.Greeting.model;

public class Greetings {
	
	private String text;
	
	public Greetings() {}

	public Greetings(String text) {
		super();
		this.text = text;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
	

}

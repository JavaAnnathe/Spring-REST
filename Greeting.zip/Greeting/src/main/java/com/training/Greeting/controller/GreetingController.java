package com.training.Greeting.controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.training.Greeting.model.Greetings;


@RestController
public class GreetingController {
	
	@GetMapping("/greetings")
	public String getGreetings() {
		
		return "Hello";
	}
	
	
	@GetMapping("/greet")
	public Greetings getGreetMessage() {
		
		Greetings greetings = new Greetings("Hello everyone");
		
		return greetings;
	}

}
